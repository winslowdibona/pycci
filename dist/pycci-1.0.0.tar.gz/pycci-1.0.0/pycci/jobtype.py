class JOBTYPE:
    ALL = 'all'
    CYPRESS = 'cypress'
    VISUAL = 'visual_testing'
    BACKEND = 'backend'
    FRONTEND = 'frontend'
